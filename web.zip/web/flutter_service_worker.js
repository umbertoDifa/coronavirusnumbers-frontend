'use strict';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "/icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"/icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"/main.dart.js": "8df4b3e83ec5f996d42fb640ceced785",
"/manifest.json": "9e537c89adf35f26d285fdd23d3f3837",
"/index.html": "adbaa435830d6ce07ebe110ada9d82f4",
"/assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "115e937bb829a890521f72d2e664b632",
"/assets/icons/custom_icons.ttf": "a0663189c2f23f3ab07f64b92adb8a14",
"/assets/fonts/MaterialIcons-Regular.ttf": "56d3ffdef7a25659eab6a68a3fbfaf16",
"/assets/LICENSE": "6bae3f2081b995b09f652dfe28cbb2da",
"/assets/AssetManifest.json": "44dc617b6abc42727ceceaa41688eefd",
"/assets/FontManifest.json": "70ead6305207a5ff887b2ca63a92b756"
};

self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (cacheName) {
      return caches.delete(cacheName);
    }).then(function (_) {
      return caches.open(CACHE_NAME);
    }).then(function (cache) {
      return cache.addAll(Object.keys(RESOURCES));
    })
  );
});

self.addEventListener('fetch', function (event) {
  event.respondWith(
    caches.match(event.request)
      .then(function (response) {
        if (response) {
          return response;
        }
        return fetch(event.request, {
          credentials: 'omit'
        });
      })
  );
});
